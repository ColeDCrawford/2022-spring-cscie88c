package org.cscie88c.week2

object UtilFunctions {

  // complete the functions below
  def maximum(a: Int, b: Int): Int =
    if (a > b) return a
    else return b
  def average(a: Int, b: Int): Double =
    (a.toDouble + b.toDouble) / 2

}
